Someothername=1    
def Func1():
    Somename = 1
    Somename=Somename  + Someothername  
    while 10  + 11 * 1:
        Somename=Somename  + Someothername  
        print(Somename)

Func1()
